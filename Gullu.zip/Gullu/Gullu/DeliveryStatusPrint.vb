﻿Public Class DeliveryStatusPrint

    Private Sub DeliveryStatusPrint_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class