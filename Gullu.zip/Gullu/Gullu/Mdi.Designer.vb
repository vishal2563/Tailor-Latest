﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mdi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mdi))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesManMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditSalesManMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.TailorMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditTailorMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.DescriptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditDescriptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripSeparator()
        Me.TItemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripSeparator()
        Me.RateMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditRateMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.UserMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditUserMasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeliveryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeliveryRegisterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator()
        Me.DeliveryStatusRegisterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripSeparator()
        Me.DeliveryDetailRegisterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterToolStripMenuItem, Me.TransactionsToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1284, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MasterToolStripMenuItem
        '
        Me.MasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalesManMasterToolStripMenuItem, Me.EditSalesManMasterToolStripMenuItem, Me.ToolStripMenuItem1, Me.TailorMasterToolStripMenuItem, Me.EditTailorMasterToolStripMenuItem, Me.ToolStripMenuItem2, Me.DescriptionToolStripMenuItem, Me.EditDescriptionToolStripMenuItem, Me.ToolStripMenuItem5, Me.TItemToolStripMenuItem, Me.ToolStripMenuItem6, Me.RateMasterToolStripMenuItem, Me.EditRateMasterToolStripMenuItem, Me.ToolStripMenuItem3, Me.UserMasterToolStripMenuItem, Me.EditUserMasterToolStripMenuItem})
        Me.MasterToolStripMenuItem.Name = "MasterToolStripMenuItem"
        Me.MasterToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.MasterToolStripMenuItem.Text = "&Master"
        '
        'SalesManMasterToolStripMenuItem
        '
        Me.SalesManMasterToolStripMenuItem.Name = "SalesManMasterToolStripMenuItem"
        Me.SalesManMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.SalesManMasterToolStripMenuItem.Text = "&SalesMan Master"
        '
        'EditSalesManMasterToolStripMenuItem
        '
        Me.EditSalesManMasterToolStripMenuItem.Name = "EditSalesManMasterToolStripMenuItem"
        Me.EditSalesManMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.EditSalesManMasterToolStripMenuItem.Text = "&Edit SalesMan Master"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(173, 6)
        '
        'TailorMasterToolStripMenuItem
        '
        Me.TailorMasterToolStripMenuItem.Name = "TailorMasterToolStripMenuItem"
        Me.TailorMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.TailorMasterToolStripMenuItem.Text = "&Tailor Master"
        '
        'EditTailorMasterToolStripMenuItem
        '
        Me.EditTailorMasterToolStripMenuItem.Name = "EditTailorMasterToolStripMenuItem"
        Me.EditTailorMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.EditTailorMasterToolStripMenuItem.Text = "Edit T&ailor Master"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(173, 6)
        '
        'DescriptionToolStripMenuItem
        '
        Me.DescriptionToolStripMenuItem.Name = "DescriptionToolStripMenuItem"
        Me.DescriptionToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.DescriptionToolStripMenuItem.Text = "&Description"
        '
        'EditDescriptionToolStripMenuItem
        '
        Me.EditDescriptionToolStripMenuItem.Name = "EditDescriptionToolStripMenuItem"
        Me.EditDescriptionToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.EditDescriptionToolStripMenuItem.Text = "Edit Descri&ption"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(173, 6)
        '
        'TItemToolStripMenuItem
        '
        Me.TItemToolStripMenuItem.Name = "TItemToolStripMenuItem"
        Me.TItemToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.TItemToolStripMenuItem.Text = "Edit Item"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(173, 6)
        '
        'RateMasterToolStripMenuItem
        '
        Me.RateMasterToolStripMenuItem.Name = "RateMasterToolStripMenuItem"
        Me.RateMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.RateMasterToolStripMenuItem.Text = "Rate Master"
        '
        'EditRateMasterToolStripMenuItem
        '
        Me.EditRateMasterToolStripMenuItem.Name = "EditRateMasterToolStripMenuItem"
        Me.EditRateMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.EditRateMasterToolStripMenuItem.Text = "Edit Rate master"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(173, 6)
        '
        'UserMasterToolStripMenuItem
        '
        Me.UserMasterToolStripMenuItem.Name = "UserMasterToolStripMenuItem"
        Me.UserMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.UserMasterToolStripMenuItem.Text = "&User Master"
        '
        'EditUserMasterToolStripMenuItem
        '
        Me.EditUserMasterToolStripMenuItem.Name = "EditUserMasterToolStripMenuItem"
        Me.EditUserMasterToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.EditUserMasterToolStripMenuItem.Text = "Edit User Master"
        '
        'TransactionsToolStripMenuItem
        '
        Me.TransactionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeliveryToolStripMenuItem})
        Me.TransactionsToolStripMenuItem.Name = "TransactionsToolStripMenuItem"
        Me.TransactionsToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.TransactionsToolStripMenuItem.Text = "&Transactions"
        '
        'DeliveryToolStripMenuItem
        '
        Me.DeliveryToolStripMenuItem.Name = "DeliveryToolStripMenuItem"
        Me.DeliveryToolStripMenuItem.Size = New System.Drawing.Size(113, 22)
        Me.DeliveryToolStripMenuItem.Text = "Delivery"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeliveryRegisterToolStripMenuItem, Me.ToolStripMenuItem4, Me.DeliveryStatusRegisterToolStripMenuItem, Me.ToolStripMenuItem7, Me.DeliveryDetailRegisterToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.ReportsToolStripMenuItem.Text = "&Reports"
        '
        'DeliveryRegisterToolStripMenuItem
        '
        Me.DeliveryRegisterToolStripMenuItem.Name = "DeliveryRegisterToolStripMenuItem"
        Me.DeliveryRegisterToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.DeliveryRegisterToolStripMenuItem.Text = "&Delivery Register"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(187, 6)
        '
        'DeliveryStatusRegisterToolStripMenuItem
        '
        Me.DeliveryStatusRegisterToolStripMenuItem.Name = "DeliveryStatusRegisterToolStripMenuItem"
        Me.DeliveryStatusRegisterToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.DeliveryStatusRegisterToolStripMenuItem.Text = "Delivery &Status Register"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(187, 6)
        '
        'DeliveryDetailRegisterToolStripMenuItem
        '
        Me.DeliveryDetailRegisterToolStripMenuItem.Name = "DeliveryDetailRegisterToolStripMenuItem"
        Me.DeliveryDetailRegisterToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.DeliveryDetailRegisterToolStripMenuItem.Text = "Delivery De&tail Register"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "&Exit"
        '
        'mdi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1284, 705)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "mdi"
        Me.Text = "Tailor"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesManMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditSalesManMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeliveryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TailorMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditTailorMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeliveryRegisterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents UserMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditUserMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DescriptionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditDescriptionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeliveryStatusRegisterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TItemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RateMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditRateMasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DeliveryDetailRegisterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
