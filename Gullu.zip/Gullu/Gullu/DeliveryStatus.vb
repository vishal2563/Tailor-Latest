﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared


Public Class DeliveryStatus
    Dim cmd, cmd1 As New SqlCommand
    Dim drd, drd1 As SqlDataReader
    Dim r As Integer = 0

    Private Sub DeliveryStatus_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Dispose()
        deliveryregister.MdiParent = mdi
        deliveryregister.Show()
        deliveryregister.clickshowtbn()
    End Sub

    Private Sub DeliveryStatus_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If editdeliverystatus = False Then
            TextBox7.Text = autonum("entryno", "deliverystatus")
            btndel.Visible = False
        End If
    End Sub

    Public Sub displaydata()        'new (not for edit)
        openconn()
        openconn1()
        cmd = New SqlCommand("select * from delivery where billno=" & TextBox1.Text, cnn)
        drd = cmd.ExecuteReader
        If drd.Read Then
            TextBox1.Text = drd("billno")
            DateTimePicker1.Text = drd("billdate")
            TextBox15.Text = drd("cstbillno")
            TextBox2.Text = drd("cstname")
            TextBox3.Text = drd("mobile")
            TextBox11.Text = Format(drd("totalqty"), "#.00")
            TextBox9.Text = Format(drd("totalstitching"), "#.00")
        End If
        drd.Close()

        r = 0
        DataGridView1.Rows.Clear()

        cmd = New SqlCommand("SELECT     a.billno, a.billdate, a.cstbillno, a.cstname, a.mobile, a.smid, a.smname, a.tid, a.tname, a.itemid,a.item, a.stitchingcharges, a.did,a.description, a.anybalance, a.totalstitching, a.stitchingrec, SUM(a.qty) AS qty, b.deliveryon, CASE WHEN b.delivered <> 0 THEN b.delivered ELSE 0 END AS delivered,  b.totalamt FROM         delivery AS a LEFT OUTER JOIN (SELECT     billno, deliveryon, item, stitchingcharges,tid, totalamt,  SUM(qty) AS delivered FROM          deliverystatus GROUP BY billno, deliveryon, item, stitchingcharges,tid, totalamt) AS b ON a.billno = b.billno AND a.item = b.item AND a.stitchingcharges = b.stitchingcharges and a.tid=b.tid WHERE    a.billno='" & TextBox1.Text & "' GROUP BY a.billno, a.billdate, a.cstbillno, a.cstname, a.mobile, a.smid, a.smname, a.tid, a.tname, a.itemid,a.item, a.stitchingcharges,a.did, a.description, a.anybalance, a.totalstitching, a.stitchingrec, b.deliveryon, b.delivered,  b.totalamt", cnn)
        drd = cmd.ExecuteReader
        While drd.Read
            DataGridView1.Rows.Add()
            DataGridView1.Rows(r).Cells("itemid").Value = drd("itemid")
            DataGridView1.Rows(r).Cells("item").Value = drd("item")
            DataGridView1.Rows(r).Cells("did").Value = drd("did")
            DataGridView1.Rows(r).Cells("description").Value = drd("description")
            DataGridView1.Rows(r).Cells("qty").Value = Format(drd("qty"), "#.00")
            If IsDBNull(drd("delivered")) Then
                DataGridView1.Rows(r).Cells("alreadydelivered").Value = 0
                DataGridView1.Rows(r).Cells("balanceqty").Value = Format(Val(drd("qty")), "#.00")
            Else
                DataGridView1.Rows(r).Cells("alreadydelivered").Value = Format(drd("delivered"), "#.00")
                DataGridView1.Rows(r).Cells("balanceqty").Value = Format(Val(drd("qty")) - Val(drd("delivered")), "#.00")
            End If

            DataGridView1.Rows(r).Cells("deliverqty").Value = ""
            DataGridView1.Rows(r).Cells("stitchingrate").Value = Format(Val(drd("stitchingcharges")), "#.00")
            DataGridView1.Rows(r).Cells("stitchingamt").Value = Format(Val(drd("qty")) * Val(drd("stitchingcharges")), "#.00")
            DataGridView1.Rows(r).Cells("tid").Value = drd("tid")
            DataGridView1.Rows(r).Cells("tname").Value = drd("tname")
            TextBox8.Text = Format(drd("anybalance"), "#.00")

            Dim amountrec As Double = 0
            cmd1 = New SqlCommand("select entryno,amountrec from deliverystatus where billno='" & TextBox1.Text & "'group by entryno,amountrec ", cnn1)
            drd1 = cmd1.ExecuteReader
            While drd1.Read
                amountrec = amountrec + Val(drd1("amountrec"))
            End While

            drd1.Close()
            TextBox10.Text = Format(Val(drd("stitchingrec")) + amountrec, "#.00")

            r = r + 1
        End While

        TextBox4.Text = Format(Val(TextBox8.Text) + Val(TextBox9.Text), "#.00")
        TextBox11.Text = Format(Val(TextBox4.Text) - Val(TextBox10.Text), "#.00")
        TextBox6.Text = Format(Val(TextBox11.Text) - Val(TextBox5.Text), "#.00")

        drd.Close()
        closeconn1()
        closeconn()
    End Sub

    Public Sub displaydata2()           'used for edit entry.(not use display1 because of entryno field .)
        r = 0
        DataGridView1.Rows.Clear()

        openconn()
        openconn1()
        cmd = New SqlCommand("select * from delivery where billno=" & TextBox1.Text, cnn)
        drd = cmd.ExecuteReader
        While drd.Read
            TextBox1.Text = drd("billno")
            DateTimePicker1.Text = drd("billdate")
            TextBox15.Text = drd("cstbillno")
            TextBox2.Text = drd("cstname")
            TextBox3.Text = drd("mobile")
            TextBox8.Text = Format(drd("anybalance"), "#.00")
            TextBox9.Text = Format(drd("totalstitching"), "#.00")

            ' totalamtrec = drd("stitchingrec")

            DataGridView1.Rows.Add()
            DataGridView1.Rows(r).Cells("item").Value = drd("item")
            DataGridView1.Rows(r).Cells("description").Value = drd("description")
            DataGridView1.Rows(r).Cells("qty").Value = Format(drd("qty"), "#.00")

            ' cmd1 = New SqlCommand("select  alreadydelivered,qty,amountrec from deliverystatus where entryno=" & TextBox7.Text & " and item='" & drd("item") & "' and description='" & drd("description") & "'", cnn1)
            cmd1 = New SqlCommand("SELECT     SUM(alreadydelivered) AS alreadydelivered, SUM(qty) AS qty, SUM(amountrec) AS amountrec FROM         deliverystatus WHERE     (billno = 1)", cnn1)
            drd1 = cmd1.ExecuteReader
            If drd1.Read Then
                DataGridView1.Rows(r).Cells("alreadydelivered").Value = Format(Val(drd1("alreadydelivered")), "#.00")
                DataGridView1.Rows(r).Cells("deliverqty").Value = Format(Val(drd1("qty")), "#.00")
                DataGridView1.Rows(r).Cells("balanceqty").Value = Format(Val(drd("qty")) - (Val(drd1("alreadydelivered")) + Val(drd1("qty"))), "#.00")

            End If
            drd1.Close()
            r = r + 1
        End While
        drd.Close()

        TextBox4.Text = Format(Val(TextBox8.Text) + Val(TextBox9.Text), "#.00")
        TextBox11.Text = Format(Val(TextBox4.Text) - Val(TextBox10.Text), "#.00")
        TextBox6.Text = Format(Val(TextBox11.Text) - Val(TextBox5.Text), "#.00")

        drd.Close()
        closeconn()
    End Sub

    Private Sub DataGridView1_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEndEdit
        If e.ColumnIndex = 6 And Val(DataGridView1.Rows(e.RowIndex).Cells("deliverqty").Value) <= Val(DataGridView1.Rows(e.RowIndex).Cells("qty").Value) And Not (Val(DataGridView1.Rows(e.RowIndex).Cells("qty").Value) - (Val(DataGridView1.Rows(e.RowIndex).Cells("alreadydelivered").Value) + Val(DataGridView1.Rows(e.RowIndex).Cells("deliverqty").Value))) < 0 Then
            DataGridView1.Rows(e.RowIndex).Cells("deliverqty").Value = Format(Val(DataGridView1.Rows(e.RowIndex).Cells("deliverqty").Value), "#.00")
            DataGridView1.Rows(e.RowIndex).Cells("balanceqty").Value = Format(Val(DataGridView1.Rows(e.RowIndex).Cells("qty").Value) - (Val(DataGridView1.Rows(e.RowIndex).Cells("alreadydelivered").Value) + Val(DataGridView1.Rows(e.RowIndex).Cells("deliverqty").Value)), "#.00")
        Else
            MsgBox("Invalid Quantity", vbCritical, "Alert!!!")
            DataGridView1.Rows(e.RowIndex).Cells("deliverqty").Value = ""
        End If
    End Sub

    Private Sub DataGridView1_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles DataGridView1.EditingControlShowing
        If DataGridView1.CurrentCell.ColumnIndex = 4 Then
            AddHandler CType(e.Control, TextBox).KeyPress, AddressOf TxtCheck_keyPress
        End If
    End Sub

    Private Sub TxtCheck_keyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If Not (Char.IsDigit(CChar(CStr(e.KeyChar))) Or e.KeyChar = "." Or Asc(e.KeyChar) = 8) Then e.Handled = True
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If editdeliverystatus = True Then
            DeleteTrans()
        Else
            TextBox7.Text = autonum("entryno", "deliverystatus")
        End If

        openconn()
        For a As Integer = 0 To DataGridView1.Rows.Count - 1

            cmd = New SqlCommand("insert into deliverystatus(entryno,billno,billdate,cstbillno,cstname,mobile,deliveryon,itemid,item,did,description,totalqty,alreadydelivered,qty,stitchingcharges,tid,tname,totalamt,alreadyrec,amountrec)values(@entryno,@billno,@billdate,@cstbillno,@cstname,@mobile,@deliveryon,@itemid,@item,@did,@description,@totalqty,@alreadydelivered,@qty,@stitchingcharges,@tid,@tname,@totalamt,@alreadyrec,@amountrec)", cnn)
            cmd.Parameters.AddWithValue("@entryno", TextBox7.Text)
            cmd.Parameters.AddWithValue("@billno", TextBox1.Text)
            cmd.Parameters.AddWithValue("@billdate", DateTimePicker1.Value.Date)
            cmd.Parameters.AddWithValue("@cstbillno", TextBox15.Text)
            cmd.Parameters.AddWithValue("@cstname", TextBox2.Text)
            cmd.Parameters.AddWithValue("@mobile", TextBox3.Text)
            cmd.Parameters.AddWithValue("@deliveryon", DateTimePicker2.Value.Date)
            cmd.Parameters.AddWithValue("@itemid", DataGridView1.Rows(a).Cells("itemid").Value)
            cmd.Parameters.AddWithValue("@item", DataGridView1.Rows(a).Cells("item").Value)
            cmd.Parameters.AddWithValue("@did", DataGridView1.Rows(a).Cells("did").Value)
            cmd.Parameters.AddWithValue("@description", DataGridView1.Rows(a).Cells("description").Value)

            cmd.Parameters.AddWithValue("@totalqty", DataGridView1.Rows(a).Cells("qty").Value)
            cmd.Parameters.AddWithValue("@alreadydelivered", DataGridView1.Rows(a).Cells("alreadydelivered").Value)
            cmd.Parameters.AddWithValue("@qty", DataGridView1.Rows(a).Cells("deliverqty").Value)

            cmd.Parameters.AddWithValue("@stitchingcharges", DataGridView1.Rows(a).Cells("stitchingrate").Value)
            cmd.Parameters.AddWithValue("@tid", DataGridView1.Rows(a).Cells("tid").Value)
            cmd.Parameters.AddWithValue("@tname", DataGridView1.Rows(a).Cells("tname").Value)

            cmd.Parameters.AddWithValue("@totalamt", TextBox4.Text)
            'cmd.Parameters.AddWithValue("@alreadyrec", TextBox10.Text)     'no need alreadyrec field can b removed
            cmd.Parameters.AddWithValue("@alreadyrec", "")
            cmd.Parameters.AddWithValue("@amountrec", TextBox5.Text)
            cmd.ExecuteNonQuery()
        Next
        closeconn()
        print()

        Dispose()
        deliveryregister.MdiParent = mdi
        deliveryregister.Show()
        deliveryregister.SendToBack()
        deliveryregister.clickshowtbn()

    End Sub

    Private Sub print()
        print_billno = TextBox1.Text
        Dim CReport As New DeliveryStatusRpt
        Dim myConnectionInfo As New ConnectionInfo()
        myConnectionInfo.ServerName = SqlServerName(1)
        myConnectionInfo.DatabaseName = SqlDataBase(1)
        myConnectionInfo.UserID = SqlUserId(1)
        myConnectionInfo.Password = SqlPassword(1)

        CReport.Load()
        Dim myTables As Tables = CReport.Database.Tables
        For Each myTable As CrystalDecisions.CrystalReports.Engine.Table In myTables
            Dim myTableLogonInfo As TableLogOnInfo = myTable.LogOnInfo
            myTableLogonInfo.ConnectionInfo = myConnectionInfo
            myTable.ApplyLogOnInfo(myTableLogonInfo)
        Next

        CReport.SetParameterValue("billno", print_billno)
        ''''CReport.RecordSelectionFormula = "{deliverystatus.billno} = " & print_billno
        DeliveryStatusPrint.CrystalReportViewer1.ReportSource = CReport
        DeliveryStatusPrint.CrystalReportViewer1.Refresh()
        CReport.PrintToPrinter(1, True, 1, 1)

        'DeliveryStatusPrint.MdiParent = mdi
        'DeliveryStatusPrint.Show()
    End Sub

    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        Dispose()
        deliveryregister.MdiParent = mdi
        deliveryregister.Show()
        deliveryregister.clickshowtbn()
    End Sub

    Private Sub TextBox5_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox5.GotFocus
        TextBox5.SelectionStart = 0
        TextBox5.SelectionLength = Len(TextBox5.Text)
    End Sub

    Private Sub TextBox5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox5.KeyPress
        If Asc(e.KeyChar) = 13 Then
            SendKeys.Send("{tab}")
        End If
    End Sub

    Private Sub TextBox5_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox5.LostFocus
        TextBox5.Text = Format(Val(TextBox5.Text), "#.00")
        TextBox6.Text = Format(Val(TextBox11.Text) - Val(TextBox5.Text), "#.00")
    End Sub

    'Private Sub calculations()
    '    Dim totalstitching As Double = 0
    '    Dim j As Integer

    '    For j = 0 To DataGridView1.Rows.Count - 1
    '        totalstitching = Val(totalstitching) + Val(DataGridView1.Rows(j).Cells("stitching").Value)
    '    Next
    '    TextBox9.Text = Format(totalstitching, "#.00")
    'End Sub
  

    'Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click
    '    Dim ch As String
    '    ch = MsgBox("Are You Sure To Delete?...", vbYesNo, "Confirm!!!")
    '    If ch = vbYes Then
    '        If Trim(TextBox1.Text) <> "" Then
    '            DeleteTrans()
    '            Dispose()
    '            DeliveryStatusRegister.MdiParent = mdi
    '            DeliveryStatusRegister.Show()
    '            DeliveryStatusRegister.clickshowtbn()
    '        End If
    '    End If
    'End Sub

    Private Sub DeleteTrans()
        openconn()
        cmd = New SqlCommand("delete from deliverystatus where entryno=" & TextBox7.Text, cnn)
        cmd.ExecuteNonQuery()
        closeconn()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class